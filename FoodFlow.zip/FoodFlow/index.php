<?php
require_once "config.php";
require_once "auth.php";

$donors = $conn->query("SELECT COUNT(*) c FROM donors")->fetch_assoc()["c"];
$donations = $conn->query("SELECT COUNT(*) c FROM donations")->fetch_assoc()["c"];
$stock = $conn->query("SELECT COALESCE(SUM(quantity),0) c FROM inventory")->fetch_assoc()["c"];
$distributed = $conn->query("SELECT COALESCE(SUM(quantity),0) c FROM distributions")->fetch_assoc()["c"];
$pending = $conn->query("SELECT COUNT(*) c FROM distributions WHERE status='Pending'")->fetch_assoc()["c"];
$low = $conn->query("SELECT COUNT(*) c FROM inventory WHERE quantity <= min_stock")->fetch_assoc()["c"];
$expiring = $conn->query("SELECT COUNT(*) c FROM inventory WHERE expiry_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND expiry_date >= CURDATE()")->fetch_assoc()["c"];
$recent = $conn->query("SELECT d.id, d.food_item, d.quantity, d.unit, d.donation_date, d.status, dr.name donor_name FROM donations d JOIN donors dr ON d.donor_id=dr.id ORDER BY d.id DESC LIMIT 6");
include "header.php";
?>
<div class="stats-grid">
    <div class="stat-card"><div class="icon green">♙</div><div><span>Active Donors</span><b><?php echo $donors; ?></b></div></div>
    <div class="stat-card"><div class="icon blue">＋</div><div><span>Total Donations</span><b><?php echo $donations; ?></b></div></div>
    <div class="stat-card"><div class="icon orange">▣</div><div><span>Food in Stock</span><b><?php echo number_format($stock,1); ?> kg</b></div></div>
    <div class="stat-card"><div class="icon purple">⇢</div><div><span>Food Distributed</span><b><?php echo number_format($distributed,1); ?> kg</b></div></div>
</div>

<div class="grid-2">
<section class="panel">
    <div class="panel-head"><div><h3>Recent Donations</h3><p>Latest food received by the bank</p></div><a class="btn small" href="donations.php">View all</a></div>
    <div class="table-wrap"><table><thead><tr><th>Donor</th><th>Food</th><th>Qty</th><th>Status</th></tr></thead><tbody>
    <?php while($r=$recent->fetch_assoc()): ?>
    <tr><td><?php echo htmlspecialchars($r["donor_name"]); ?></td><td><?php echo htmlspecialchars($r["food_item"]); ?></td><td><?php echo $r["quantity"]." ".$r["unit"]; ?></td><td><span class="badge <?php echo strtolower($r["status"]); ?>"><?php echo $r["status"]; ?></span></td></tr>
    <?php endwhile; ?>
    </tbody></table></div>
</section>
<section class="panel">
    <div class="panel-head"><div><h3>Attention Needed</h3><p>Items that may require action</p></div></div>
    <div class="notice-list">
        <div class="notice"><span class="notice-icon orange">!</span><div><b><?php echo $low; ?> low-stock item(s)</b><p>Check inventory and arrange donations.</p></div></div>
        <div class="notice"><span class="notice-icon red">⌛</span><div><b><?php echo $expiring; ?> item(s) expiring soon</b><p>Prioritise these items for distribution.</p></div></div>
        <div class="notice"><span class="notice-icon blue">→</span><div><b><?php echo $pending; ?> pending request(s)</b><p>Review distribution requests.</p></div></div>
    </div>
</section>
</div>

<section class="quick-grid">
<a href="donations.php?action=add" class="quick-card"><span>＋</span><div><b>Record Donation</b><small>Add newly received food</small></div></a>
<a href="donors.php?action=add" class="quick-card"><span>♙</span><div><b>Add Donor</b><small>Register a local donor</small></div></a>
<a href="distribution.php?action=add" class="quick-card"><span>⇢</span><div><b>New Distribution</b><small>Create a beneficiary request</small></div></a>
</section>
<?php include "footer.php"; ?>
