# FoodFlow - Local Food Bank Supply Chain & Donation Tracker

B.Sc. IT Second Year Project

## Technology
HTML5, CSS3, JavaScript, PHP, MySQL

## Modules
- Admin login
- Dashboard
- Donor management
- Donation management
- Inventory management
- Distribution / beneficiary requests
- Reports
- Search and status filters
- Low stock and expiry alerts

## Setup
1. Install XAMPP.
2. Copy the `FoodFlow` folder into `htdocs`.
3. Start Apache and MySQL.
4. Open phpMyAdmin and import `database/foodflow.sql`.
5. Visit: http://localhost/FoodFlow/
6. Demo login: admin@foodflow.local / admin123

The project is intentionally kept at a B.Sc. IT second-year level so the database, PHP flow and CRUD operations are easy to explain in a viva.
