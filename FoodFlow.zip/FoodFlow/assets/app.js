function toggleSidebar(){
    document.getElementById('sidebar').classList.toggle('show');
}
function openModal(id){
    const el=document.getElementById(id);
    if(el) el.classList.add('open');
}
function closeModal(id){
    const el=document.getElementById(id);
    if(el) el.classList.remove('open');
}
document.addEventListener('click', function(e){
    if(e.target.classList.contains('modal')) e.target.classList.remove('open');
});
function filterTable(inputId, tableId){
    const q=document.getElementById(inputId).value.toLowerCase();
    const rows=document.querySelectorAll('#'+tableId+' tbody tr');
    rows.forEach(row=>row.style.display=row.innerText.toLowerCase().includes(q)?'':'none');
}
function editStock(id, qty){
    document.getElementById('stockId').value=id;
    document.getElementById('stockQty').value=qty;
    openModal('stockModal');
}
