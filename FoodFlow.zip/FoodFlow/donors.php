<?php
require_once "config.php"; require_once "auth.php";
$message="";
if(isset($_GET["delete"])){
    $id=(int)$_GET["delete"];
    $stmt=$conn->prepare("DELETE FROM donors WHERE id=?"); $stmt->bind_param("i",$id); $stmt->execute();
    $message="Donor removed successfully.";
}
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $name=trim($_POST["name"]); $phone=trim($_POST["phone"]); $email=trim($_POST["email"]); $address=trim($_POST["address"]);
    $stmt=$conn->prepare("INSERT INTO donors(name,phone,email,address) VALUES(?,?,?,?)");
    $stmt->bind_param("ssss",$name,$phone,$email,$address); $stmt->execute(); $message="Donor added successfully.";
}
$rows=$conn->query("SELECT * FROM donors ORDER BY id DESC");
include "header.php";
?>
<div class="page-actions"><div><h3>Donor Management</h3><p>Maintain the list of people and organisations supporting the food bank.</p></div><button class="btn primary" onclick="openModal('donorModal')">＋ Add Donor</button></div>
<?php if($message): ?><div class="alert success"><?php echo $message; ?></div><?php endif; ?>
<section class="panel">
<div class="searchbar"><input id="donorSearch" onkeyup="filterTable('donorSearch','donorTable')" placeholder="Search donors..."></div>
<div class="table-wrap"><table id="donorTable"><thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Address</th><th>Action</th></tr></thead><tbody>
<?php while($r=$rows->fetch_assoc()): ?><tr>
<td><b><?php echo htmlspecialchars($r["name"]); ?></b></td><td><?php echo htmlspecialchars($r["phone"]); ?></td><td><?php echo htmlspecialchars($r["email"]); ?></td><td><?php echo htmlspecialchars($r["address"]); ?></td>
<td><a class="danger-link" onclick="return confirm('Remove this donor?')" href="?delete=<?php echo $r["id"]; ?>">Delete</a></td>
</tr><?php endwhile; ?>
</tbody></table></div></section>

<div class="modal" id="donorModal"><div class="modal-box"><button class="close" onclick="closeModal('donorModal')">×</button><h3>Add New Donor</h3>
<form method="post" class="form-grid"><div><label>Donor Name *</label><input name="name" required></div><div><label>Phone *</label><input name="phone" required></div><div><label>Email</label><input type="email" name="email"></div><div><label>Address</label><input name="address"></div><div class="full-row"><button class="btn primary" type="submit">Save Donor</button></div></form>
</div></div>
<?php include "footer.php"; ?>
