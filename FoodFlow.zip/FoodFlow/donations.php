<?php
require_once "config.php"; require_once "auth.php";
$message="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $donor=(int)$_POST["donor_id"]; $food=trim($_POST["food_item"]); $qty=(float)$_POST["quantity"]; $unit=$_POST["unit"]; $expiry=$_POST["expiry_date"]; $date=$_POST["donation_date"];
    $stmt=$conn->prepare("INSERT INTO donations(donor_id,food_item,quantity,unit,expiry_date,donation_date,status) VALUES(?,?,?,?,?,?, 'Received')");
    $stmt->bind_param("isdsss",$donor,$food,$qty,$unit,$expiry,$date); $stmt->execute();

    $check=$conn->prepare("SELECT id FROM inventory WHERE food_item=? AND unit=? AND expiry_date=?");
    $check->bind_param("sss",$food,$unit,$expiry); $check->execute(); $found=$check->get_result()->fetch_assoc();
    if($found){
        $up=$conn->prepare("UPDATE inventory SET quantity=quantity+? WHERE id=?"); $up->bind_param("di",$qty,$found["id"]); $up->execute();
    } else {
        $in=$conn->prepare("INSERT INTO inventory(food_item,quantity,unit,expiry_date,min_stock) VALUES(?,?,?,?,10)");
        $in->bind_param("sdss",$food,$qty,$unit,$expiry); $in->execute();
    }
    $message="Donation recorded and inventory updated.";
}
$donors=$conn->query("SELECT id,name FROM donors ORDER BY name");
$rows=$conn->query("SELECT d.*, dr.name donor_name FROM donations d JOIN donors dr ON d.donor_id=dr.id ORDER BY d.id DESC");
include "header.php";
?>
<div class="page-actions"><div><h3>Donation Tracker</h3><p>Record incoming food donations and automatically update stock.</p></div><button class="btn primary" onclick="openModal('donationModal')">＋ Record Donation</button></div>
<?php if($message): ?><div class="alert success"><?php echo $message; ?></div><?php endif; ?>
<section class="panel"><div class="searchbar"><input id="donationSearch" onkeyup="filterTable('donationSearch','donationTable')" placeholder="Search by donor or food item..."></div>
<div class="table-wrap"><table id="donationTable"><thead><tr><th>Donor</th><th>Food Item</th><th>Quantity</th><th>Expiry</th><th>Date</th><th>Status</th></tr></thead><tbody>
<?php while($r=$rows->fetch_assoc()): ?><tr><td><?php echo htmlspecialchars($r["donor_name"]); ?></td><td><b><?php echo htmlspecialchars($r["food_item"]); ?></b></td><td><?php echo $r["quantity"]." ".$r["unit"]; ?></td><td><?php echo date("d M Y",strtotime($r["expiry_date"])); ?></td><td><?php echo date("d M Y",strtotime($r["donation_date"])); ?></td><td><span class="badge received">Received</span></td></tr><?php endwhile; ?>
</tbody></table></div></section>

<div class="modal" id="donationModal"><div class="modal-box"><button class="close" onclick="closeModal('donationModal')">×</button><h3>Record Donation</h3>
<form method="post" class="form-grid">
<div><label>Donor *</label><select name="donor_id" required><option value="">Select donor</option><?php while($d=$donors->fetch_assoc()): ?><option value="<?php echo $d["id"]; ?>"><?php echo htmlspecialchars($d["name"]); ?></option><?php endwhile; ?></select></div>
<div><label>Food Item *</label><input name="food_item" placeholder="Rice, Dal, Wheat..." required></div>
<div><label>Quantity *</label><input type="number" step="0.1" min="0.1" name="quantity" required></div>
<div><label>Unit</label><select name="unit"><option>kg</option><option>litre</option><option>packets</option><option>boxes</option></select></div>
<div><label>Expiry Date *</label><input type="date" name="expiry_date" required></div>
<div><label>Donation Date *</label><input type="date" name="donation_date" value="<?php echo date('Y-m-d'); ?>" required></div>
<div class="full-row"><button class="btn primary">Save Donation</button></div>
</form></div></div>
<?php include "footer.php"; ?>
