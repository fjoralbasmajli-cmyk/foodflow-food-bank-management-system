<?php
require_once "config.php"; require_once "auth.php";
if(isset($_POST["update_stock"])){
    $id=(int)$_POST["id"]; $qty=(float)$_POST["quantity"];
    $stmt=$conn->prepare("UPDATE inventory SET quantity=? WHERE id=?"); $stmt->bind_param("di",$qty,$id); $stmt->execute();
}
$rows=$conn->query("SELECT * FROM inventory ORDER BY expiry_date ASC");
include "header.php";
?>
<div class="page-actions"><div><h3>Food Inventory</h3><p>Track available stock, minimum levels and expiry dates.</p></div></div>
<section class="panel"><div class="table-wrap"><table><thead><tr><th>Food Item</th><th>Available</th><th>Minimum</th><th>Expiry Date</th><th>Stock Status</th><th>Action</th></tr></thead><tbody>
<?php while($r=$rows->fetch_assoc()):
$days=(strtotime($r["expiry_date"])-strtotime(date("Y-m-d")))/86400;
$status=$r["quantity"] <= $r["min_stock"] ? "Low Stock" : ($days<=7 ? "Expiring Soon" : "Good");
$class=$status==="Good"?"received":($status==="Low Stock"?"pending":"danger");
?>
<tr><td><b><?php echo htmlspecialchars($r["food_item"]); ?></b></td><td><?php echo $r["quantity"]." ".$r["unit"]; ?></td><td><?php echo $r["min_stock"]; ?></td><td><?php echo date("d M Y",strtotime($r["expiry_date"])); ?></td><td><span class="badge <?php echo $class; ?>"><?php echo $status; ?></span></td>
<td><button class="text-btn" onclick="editStock(<?php echo $r['id']; ?>,<?php echo $r['quantity']; ?>)">Update</button></td></tr>
<?php endwhile; ?>
</tbody></table></div></section>
<div class="modal" id="stockModal"><div class="modal-box"><button class="close" onclick="closeModal('stockModal')">×</button><h3>Update Stock</h3><form method="post"><input type="hidden" id="stockId" name="id"><label>Available Quantity</label><input id="stockQty" type="number" step="0.1" name="quantity" required><button class="btn primary full" name="update_stock">Update Stock</button></form></div></div>
<?php include "footer.php"; ?>
