<?php
require_once "config.php"; require_once "auth.php";
$message="";
if($_SERVER["REQUEST_METHOD"]==="POST"){
    $name=trim($_POST["beneficiary_name"]); $food=trim($_POST["food_item"]); $qty=(float)$_POST["quantity"]; $priority=$_POST["priority"]; $date=$_POST["request_date"];
    $stmt=$conn->prepare("INSERT INTO distributions(beneficiary_name,food_item,quantity,priority,request_date,status) VALUES(?,?,?,?,?,'Pending')");
    $stmt->bind_param("ssdss",$name,$food,$qty,$priority,$date); $stmt->execute(); $message="Distribution request created.";
}
if(isset($_GET["deliver"])){
    $id=(int)$_GET["deliver"];
    $r=$conn->query("SELECT * FROM distributions WHERE id=$id")->fetch_assoc();
    if($r && $r["status"]!=="Delivered"){
        $food=$conn->real_escape_string($r["food_item"]);
        $stock=$conn->query("SELECT id,quantity FROM inventory WHERE food_item='$food' ORDER BY expiry_date ASC LIMIT 1")->fetch_assoc();
        if($stock && $stock["quantity"] >= $r["quantity"]){
            $new=$stock["quantity"]-$r["quantity"];
            $conn->query("UPDATE inventory SET quantity=$new WHERE id=".$stock["id"]);
            $conn->query("UPDATE distributions SET status='Delivered', delivery_date=CURDATE() WHERE id=$id");
            $message="Request marked as delivered and inventory reduced.";
        } else $message="Not enough stock available for this request.";
    }
}
$rows=$conn->query("SELECT * FROM distributions ORDER BY id DESC");
include "header.php";
?>
<div class="page-actions"><div><h3>Distribution & Requests</h3><p>Manage food requests from families and local organisations.</p></div><button class="btn primary" onclick="openModal('distributionModal')">＋ New Request</button></div>
<?php if($message): ?><div class="alert success"><?php echo $message; ?></div><?php endif; ?>
<section class="panel"><div class="table-wrap"><table><thead><tr><th>Beneficiary</th><th>Food</th><th>Quantity</th><th>Priority</th><th>Request Date</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php while($r=$rows->fetch_assoc()): ?><tr><td><b><?php echo htmlspecialchars($r["beneficiary_name"]); ?></b></td><td><?php echo htmlspecialchars($r["food_item"]); ?></td><td><?php echo $r["quantity"]." kg"; ?></td><td><span class="badge <?php echo strtolower($r["priority"]); ?>"><?php echo $r["priority"]; ?></span></td><td><?php echo date("d M Y",strtotime($r["request_date"])); ?></td><td><span class="badge <?php echo strtolower($r["status"]); ?>"><?php echo $r["status"]; ?></span></td><td><?php if($r["status"]==="Pending"): ?><a class="text-btn" href="?deliver=<?php echo $r["id"]; ?>">Mark Delivered</a><?php else: ?>—<?php endif; ?></td></tr><?php endwhile; ?>
</tbody></table></div></section>
<div class="modal" id="distributionModal"><div class="modal-box"><button class="close" onclick="closeModal('distributionModal')">×</button><h3>New Distribution Request</h3><form method="post" class="form-grid">
<div><label>Beneficiary / Organisation *</label><input name="beneficiary_name" required></div><div><label>Food Item *</label><input name="food_item" required></div>
<div><label>Quantity (kg) *</label><input type="number" step="0.1" name="quantity" required></div><div><label>Priority</label><select name="priority"><option>Normal</option><option>High</option><option>Urgent</option></select></div>
<div><label>Request Date</label><input type="date" name="request_date" value="<?php echo date('Y-m-d'); ?>" required></div><div class="full-row"><button class="btn primary">Create Request</button></div>
</form></div></div>
<?php include "footer.php"; ?>
