<?php
session_start();
require_once "config.php";

$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    $stmt = $conn->prepare("SELECT id, name, password FROM admins WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $admin = $result->fetch_assoc();

    if ($admin && password_verify($password, $admin["password"])) {
        $_SESSION["admin_id"] = $admin["id"];
        $_SESSION["admin_name"] = $admin["name"];
        header("Location: index.php");
        exit();
    } else {
        $error = "Invalid email or password.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FoodFlow | Login</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body class="login-page">
<div class="login-card">
    <div class="brand-mark">FF</div>
    <h1>FoodFlow</h1>
    <p class="muted">Local Food Bank Management System</p>
    <?php if ($error): ?><div class="alert danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
    <form method="post">
        <label>Email</label>
        <input type="email" name="email" value="admin@foodflow.local" required>
        <label>Password</label>
        <input type="password" name="password" value="admin123" required>
        <button class="btn primary full" type="submit">Sign In</button>
    </form>
    <small>Demo account: admin@foodflow.local / admin123</small>
</div>
</body>
</html>
