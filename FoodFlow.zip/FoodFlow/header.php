<?php
require_once "auth.php";
$page = basename($_SERVER["PHP_SELF"]);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FoodFlow | <?php echo htmlspecialchars($page); ?></title>
<link rel="stylesheet" href="assets/style.css">
<script defer src="assets/app.js"></script>
</head>
<body>
<div class="app">
<aside class="sidebar" id="sidebar">
    <div class="logo"><span>FF</span><div><strong>FoodFlow</strong><small>Food Bank System</small></div></div>
    <nav>
        <a class="<?php echo $page==='index.php'?'active':''; ?>" href="index.php">⌂ <span>Dashboard</span></a>
        <a class="<?php echo $page==='donors.php'?'active':''; ?>" href="donors.php">♙ <span>Donors</span></a>
        <a class="<?php echo $page==='donations.php'?'active':''; ?>" href="donations.php">＋ <span>Donations</span></a>
        <a class="<?php echo $page==='inventory.php'?'active':''; ?>" href="inventory.php">▣ <span>Inventory</span></a>
        <a class="<?php echo $page==='distribution.php'?'active':''; ?>" href="distribution.php">⇢ <span>Distribution</span></a>
        <a class="<?php echo $page==='reports.php'?'active':''; ?>" href="reports.php">▤ <span>Reports</span></a>
    </nav>
    <div class="sidebar-bottom">
        <a href="logout.php">↪ <span>Logout</span></a>
    </div>
</aside>
<main class="main">
<header class="topbar">
    <button class="menu-btn" onclick="toggleSidebar()">☰</button>
    <div>
        <h2><?php echo ucfirst(str_replace(".php","",$page)); ?></h2>
        <p>Manage your local food bank operations</p>
    </div>
    <div class="user-chip"><span>●</span><?php echo htmlspecialchars($_SESSION["admin_name"] ?? "Admin"); ?></div>
</header>
<div class="content">
