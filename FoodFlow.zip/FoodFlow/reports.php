<?php
require_once "config.php"; require_once "auth.php";
$totalDonated=$conn->query("SELECT COALESCE(SUM(quantity),0) c FROM donations")->fetch_assoc()["c"];
$totalDistributed=$conn->query("SELECT COALESCE(SUM(quantity),0) c FROM distributions WHERE status='Delivered'")->fetch_assoc()["c"];
$requests=$conn->query("SELECT COUNT(*) c FROM distributions")->fetch_assoc()["c"];
$delivered=$conn->query("SELECT COUNT(*) c FROM distributions WHERE status='Delivered'")->fetch_assoc()["c"];
$rate=$requests?round(($delivered/$requests)*100):0;
$top=$conn->query("SELECT food_item, SUM(quantity) total FROM donations GROUP BY food_item ORDER BY total DESC LIMIT 5");
include "header.php";
?>
<div class="page-actions"><div><h3>Reports & Summary</h3><p>A simple overview of the food bank's performance.</p></div><button class="btn" onclick="window.print()">Print Report</button></div>
<div class="report-grid">
<div class="report-card"><span>Total Food Donated</span><b><?php echo number_format($totalDonated,1); ?> kg</b><small>All recorded donations</small></div>
<div class="report-card"><span>Total Food Distributed</span><b><?php echo number_format($totalDistributed,1); ?> kg</b><small>Successfully delivered</small></div>
<div class="report-card"><span>Total Requests</span><b><?php echo $requests; ?></b><small>Beneficiary requests</small></div>
<div class="report-card"><span>Delivery Rate</span><b><?php echo $rate; ?>%</b><small>Completed requests</small></div>
</div>
<section class="panel"><div class="panel-head"><div><h3>Most Donated Food Items</h3><p>Based on recorded donation quantity</p></div></div>
<div class="simple-bars"><?php while($r=$top->fetch_assoc()): ?><div class="bar-row"><span><?php echo htmlspecialchars($r["food_item"]); ?></span><div class="bar"><i style="width:<?php echo min(100,max(8,($r["total"]/$totalDonated)*100)); ?>%"></i></div><b><?php echo number_format($r["total"],1); ?> kg</b></div><?php endwhile; ?></div>
</section>
<?php include "footer.php"; ?>
