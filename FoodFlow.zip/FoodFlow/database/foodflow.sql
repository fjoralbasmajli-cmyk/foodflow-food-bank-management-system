CREATE DATABASE IF NOT EXISTS foodflow;
USE foodflow;

DROP TABLE IF EXISTS distributions;
DROP TABLE IF EXISTS donations;
DROP TABLE IF EXISTS inventory;
DROP TABLE IF EXISTS donors;
DROP TABLE IF EXISTS admins;

CREATE TABLE admins (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(120) NOT NULL UNIQUE,
 password VARCHAR(255) NOT NULL
);

CREATE TABLE donors (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(120) NOT NULL,
 phone VARCHAR(20) NOT NULL,
 email VARCHAR(120),
 address VARCHAR(255),
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE donations (
 id INT AUTO_INCREMENT PRIMARY KEY,
 donor_id INT NOT NULL,
 food_item VARCHAR(100) NOT NULL,
 quantity DECIMAL(10,2) NOT NULL,
 unit VARCHAR(20) NOT NULL,
 expiry_date DATE NOT NULL,
 donation_date DATE NOT NULL,
 status VARCHAR(30) DEFAULT 'Received',
 FOREIGN KEY (donor_id) REFERENCES donors(id) ON DELETE CASCADE
);

CREATE TABLE inventory (
 id INT AUTO_INCREMENT PRIMARY KEY,
 food_item VARCHAR(100) NOT NULL,
 quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
 unit VARCHAR(20) NOT NULL DEFAULT 'kg',
 expiry_date DATE NOT NULL,
 min_stock DECIMAL(10,2) NOT NULL DEFAULT 10
);

CREATE TABLE distributions (
 id INT AUTO_INCREMENT PRIMARY KEY,
 beneficiary_name VARCHAR(120) NOT NULL,
 food_item VARCHAR(100) NOT NULL,
 quantity DECIMAL(10,2) NOT NULL,
 priority VARCHAR(20) DEFAULT 'Normal',
 request_date DATE NOT NULL,
 delivery_date DATE NULL,
 status VARCHAR(30) DEFAULT 'Pending'
);

INSERT INTO admins(name,email,password) VALUES
('FoodFlow Admin','admin@foodflow.local', '$2y$10$8Q4QW2u1c2n1n8kQzVvK2OqM8cY4F7rT2W8V1u0nZfV3fZ0J9QyQK');

INSERT INTO donors(name,phone,email,address) VALUES
('Shree Ganesh Grocery','9876543210','ganesh@example.com','Nevasa'),
('Asha Mahila Mandal','9822334455','asha@example.com','Ahmednagar'),
('Rahul Patil','9766554433','rahul@example.com','Newasa Phata'),
('Helping Hands Cafe','9898989898','cafe@example.com','Ahmednagar');

INSERT INTO inventory(food_item,quantity,unit,expiry_date,min_stock) VALUES
('Rice',125,'kg',DATE_ADD(CURDATE(),INTERVAL 90 DAY),25),
('Wheat Flour',80,'kg',DATE_ADD(CURDATE(),INTERVAL 60 DAY),20),
('Toor Dal',42,'kg',DATE_ADD(CURDATE(),INTERVAL 45 DAY),15),
('Biscuits',18,'packets',DATE_ADD(CURDATE(),INTERVAL 6 DAY),20),
('Cooking Oil',32,'litre',DATE_ADD(CURDATE(),INTERVAL 120 DAY),10);

INSERT INTO donations(donor_id,food_item,quantity,unit,expiry_date,donation_date,status) VALUES
(1,'Rice',50,'kg',DATE_ADD(CURDATE(),INTERVAL 90 DAY),CURDATE(),'Received'),
(2,'Wheat Flour',35,'kg',DATE_ADD(CURDATE(),INTERVAL 60 DAY),CURDATE(),'Received'),
(3,'Toor Dal',20,'kg',DATE_ADD(CURDATE(),INTERVAL 45 DAY),DATE_SUB(CURDATE(),INTERVAL 2 DAY),'Received'),
(4,'Biscuits',10,'packets',DATE_ADD(CURDATE(),INTERVAL 6 DAY),DATE_SUB(CURDATE(),INTERVAL 1 DAY),'Received');

INSERT INTO distributions(beneficiary_name,food_item,quantity,priority,request_date,delivery_date,status) VALUES
('Asha Seva Kendra','Rice',20,'High',DATE_SUB(CURDATE(),INTERVAL 3 DAY),CURDATE(),'Delivered'),
('Local Community Centre','Wheat Flour',15,'Normal',DATE_SUB(CURDATE(),INTERVAL 1 DAY),NULL,'Pending'),
('Sai Foundation','Toor Dal',10,'Urgent',CURDATE(),NULL,'Pending');
